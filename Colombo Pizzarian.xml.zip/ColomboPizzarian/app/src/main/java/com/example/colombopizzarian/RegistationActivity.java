package com.example.colombopizzarian;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class RegistationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registation);
    }

    public void register(View view) {
        Toast.makeText(this, "Sucessfully you have registered for new Account", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(RegistationActivity.this, LoginActivity.class));
    }

    public void login(View view) {
        startActivity(new Intent(RegistationActivity.this, LoginActivity.class));
    }
}