package com.example.colombopizzarian.Adapter;

import com.example.colombopizzarian.Models.HomeVerModel;

import java.util.ArrayList;

public interface UpdateVerticalRec {
    public void callBack(int position, ArrayList<HomeVerModel> list);
}
