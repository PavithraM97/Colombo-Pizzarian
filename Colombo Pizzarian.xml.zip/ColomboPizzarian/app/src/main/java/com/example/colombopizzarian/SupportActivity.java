package com.example.colombopizzarian;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;

public class SupportActivity extends Fragment {

    EditText txtNum,txtMsg;
    TextView lblcount;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_support,container,false);


        txtNum = root.findViewById(R.id.txtMobile);
        txtMsg=root.findViewById(R.id.txtMessage);
        lblcount=root.findViewById(R.id.lblCount);

        txtMsg.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                lblcount.setText(charSequence.length()+"/160");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        return root;
    }

    public void sendsms (View view){
        String number = txtNum.getText().toString();
        String message = txtMsg.getText().toString();
        SmsManager smsManager = SmsManager.getDefault();

        if(Build.VERSION.SDK_INT >= 23) {
            smsManager.sendTextMessage(number,null,message,null,null);
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }

    }

}


