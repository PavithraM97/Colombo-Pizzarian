package com.example.colombopizzarian;

public class LogoutFragment {
}
